#include "UserData.h"

CUserData::CUserData(void)
	:pNext(NULL)
{

}
	CUserData::~CUserData(void)
{

}