#pragma once

class CMyListl;
class CUserInterface
{
public:
	CUserInterface::CUserInterface();
	{

	}
	CUserInterface::~CUserInterface(void);
	{

	}
	void add;

protected:
	CmyList &m_List;

public:
	void Search(void);
	void Remove(void);
	int PrintUI(void);
	int Run(void);
};
