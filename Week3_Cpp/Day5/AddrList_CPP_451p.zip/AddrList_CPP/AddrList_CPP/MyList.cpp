#include "MyList";
CMyList::CMyList() { }
CMyList::~CMyList() { }

void CMyList::PrintAll(void){ }



