#include <linux/module.h>
#include <linux/init.h>
#include <linux/major.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/kernel.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <linux/delay.h>
#include <linux/timer.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>   /* kmalloc() */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <asm/uaccess.h>
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/device.h>
#define DEVICE_NAME "sk"
#define GPGCON *(volatile unsigned long *)(kva)
#define GPGDAT *(volatile unsigned long *)(kva + 4)

struct timer_list timer;

static int sk_major = 0, sk_minor = 0;
static int result;
static dev_t sk_dev;
static void *kva;

module_param(sk_major, int, 0);

//rmmod timerTest_mod.ko
static struct cdev sk_cdev;
static int sk_register_cdev(void);

static int LED_open(struct inode *inode, struct file *filp);
static int LED_release(struct inode *inode, struct file *filp);
static int LED_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos);
static int LED_read(struct file *filp, char *buf, size_t count, loff_t *f_pos);
/* TODO: Implementation of functions */

static int LED_open(struct inode *inode, struct file *filp)
{
	printk(KERN_INFO "timerTest Module is Loaded!! ....\n");

	init_timer(&timer);
	//from origin code
	//timer.expires = get_jiffies_64() + 3*HZ;
	timer.expires = jiffies + 3*HZ;
	timer.function = my_timer;
	timer.data = 5;
	add_timer(&timer);
    printk("Device has been opened...\n");
    /* H/W Initalization */
    //kva = ioremap(0x56000060, 16);
    //printk("kva = 0x%x\n", (int)kva);
    GPGDAT |= 0xf << 4;
    GPGCON &= ~(0xff << 8);
    GPGCON |= 0x55 << 8;
    return 0;
}

static int LED_release(struct inode *inode, struct file *filp)
{
    printk("Device has been closed...\n");
    return 0;
}

static int LED_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
  volatile int i;
  printk("LED on\n");
  GPGDAT ^= (0xf << 4);
  return count;
}

static int LED_read(struct file *filp, char *buf, size_t count, loff_t *f_pos)
{
  return 0;
}


/*
// file ops
  .open    = LED_open,
  .release = LED_release,
  .write   = LED_write,
  .read    = LED_read,
*/
void my_timer(unsigned long data)
{
	//int i;
	//for(i=1; i<=data; i++) {
	//	printk("Kernel Timer Time-Out Function Doing_%d...\n", i);
	//}
	//volatile int i;
	printk("LED on\n");
	GPGDAT ^= (0xf << 4);
	//GPGDAT &= ~(0xf  <<  4);
  	// for(i=0; i<30; i++)
  	// {
   // 		GPGDAT ^= (0xf << 4);
   //  	mdelay(1000);
  	// }
  
	timer.expires = jiffies + 10*HZ;
	add_timer(&timer);

	printk("Kernel Timer Time-Out Function Done!!!\n");
}


struct file_operations sk_fops = { 
  //.owner   = THIS_MODULE,
  .open    = LED_open,
  .release = LED_release,
  .write   = LED_write,
  .read    = LED_read,
  //.unlocked_ioctl   = sk_ioctl,
};



int timerTest_init(void)
{

    printk("LED Module BySK Module is up... \n");
    
    if((result = sk_register_cdev()) < 0)
    {
      return result;
    }
    
    kva = ioremap(0x56000060, 16);
    printk("kva = 0x%x\n", (int)kva);
    GPGDAT |= 0xf << 4;
    GPGCON &= ~(0xff << 8);
    GPGCON |= 0x55 << 8;
	return 0;
}


static int sk_register_cdev(void)
{
  int error;

  /* allocation device number */
  if(sk_major) {
    sk_dev = MKDEV(sk_major, sk_minor);
    error = register_chrdev_region(sk_dev, 1, "sk");
  } else {
    error = alloc_chrdev_region(&sk_dev, sk_minor, 1, "sk");
    sk_major = MAJOR(sk_dev);
  }

  if(error < 0) {
    printk(KERN_WARNING "sk: can't get major %d\n", sk_major);
    return result;
  }
  printk("major number=%d\n", sk_major);

  /* register chrdev */
  cdev_init(&sk_cdev, &sk_fops);
  sk_cdev.owner = THIS_MODULE;
  sk_cdev.ops = &sk_fops;
  error = cdev_add(&sk_cdev, sk_dev, 1);

  if(error)
    printk(KERN_NOTICE "sk Register Error %d\n", error);

  return 0;
}


void timerTest_exit(void)
{
	printk("timerTest Module is Unloaded ....\n");
	del_timer(&timer);
	
	printk("The module is down...\n");
	cdev_del(&sk_cdev);
	unregister_chrdev_region(sk_dev, 1);
}

module_init(timerTest_init);
module_exit(timerTest_exit);

MODULE_LICENSE("Dual BSD/GPL");


/*
 #tail -f /var/log/messages
*/
