#include <linux/module.h>	/* Needed by all modules */
#include <linux/kernel.h>	/* Needed for KERN_INFO	*/
#include <linux/init.h>		/* Needed for the macros */
#include <linux/kdev_t.h>
#include <linux/cdev.h>
#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/device.h>
#include <linux/fs.h>       /* everything... */
#include <linux/types.h>    /* size_t */

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>

#include <mach/gpio.h>
#include <mach/regs-gpio.h>

#include <plat/gpio-cfg.h>


#define	DRIVER_AUTHOR	"DHKim of southkorea"
#define	DRIVER_DESC		"DHKim sample DD"
#define DRV_NAME        "mydrv"
#define DEVICE_NAME 	"mydrv"
#define MAX_MYDRV_DEV 1

static int mydrv_major = 240;
module_param(mydrv_major, int, 0);
static char str1 = "doremidoremi!!"


//
static void mydrv_setup_cdev(struct cdev *dev, int minor,struct file_operations *fops);

//
static int mydrv_open(struct inode *inode, struct file *file)
{
  printk("DHKim DD.drv opened !!\n");
  return 0;
}

static int mydrv_release(struct inode *inode, struct file *file)
{
  printk("DHKim D.drv released !!\n");
  return 0;
}


static ssize_t mydrv_read(struct file *filp, char __user *buf, size_t count,
                loff_t *f_pos)
{
  char *k_buf;
  int i;
    printk("read in func\n");

  k_buf = kmalloc(count,GFP_KERNEL);
  for(i = 0 ;i < count;i++)
      k_buf[i] = 'A' + i;
  
  if(copy_to_user(buf,k_buf,count))
  	return -EFAULT;
  printk("read is invoked\n");
  kfree(k_buf);
  return 0;

}

static ssize_t mydrv_write(struct file *filp,const char __user *buf, size_t count,
                            loff_t *f_pos)
{
  char *k_buf;
  printk("write in func\n");

  k_buf = kmalloc(count,GFP_KERNEL);
  if(copy_from_user(k_buf,buf,count))
  	return -EFAULT;
  printk("k_buf = %s\n",k_buf);
  printk("write is invoked\n");
  kfree(k_buf);
  return 0;
}


static irqreturn_t keyinterrupt_func(int irq, void *dev_id, struct pt_regs *resgs)
{
      printk("%d Key pressed....\n",irq);

      return IRQ_HANDLED;
}

static void mydrv_setup_cdev(struct cdev *dev, int minor,
		struct file_operations *fops)
{
	int err, devno = MKDEV(mydrv_major, minor);
    
	cdev_init(dev, fops);
	dev->owner = THIS_MODULE;
	dev->ops = fops;
	err = cdev_add (dev, devno, 1);
	
	if (err)
		printk (KERN_NOTICE "Error %d adding mydrv%d", err, minor);
}


/***********************************************
************************************************
************************************************
***********************************************/
static struct file_operations mydrv_fops = {
	.owner   = THIS_MODULE,
   	.open    = mydrv_open,
	.read	   = mydrv_read,
    .write   = mydrv_write,
	.release = mydrv_release,
};


static struct cdev MydrvDevs[MAX_MYDRV_DEV];

static int __init init(void)
{
	int result;
	int ret;
	dev_t dev = MKDEV(mydrv_major, 0);
	//=section of inerterupt=======================================================================
	printk(KERN_INFO "Hello DD world !!\n");
       	///*
    	// set Interrupt mode
        s3c_gpio_cfgpin(S3C2410_GPF(0), S3C_GPIO_SFN(2));
        s3c_gpio_cfgpin(S3C2410_GPF(1), S3C_GPIO_SFN(2));

        if(request_irq(IRQ_EINT0,(void *)keyinterrupt_func,IRQF_DISABLED|IRQF_TRIGGER_FALLING, DRV_NAME, NULL))
        {
                printk("IRQ_EINT0 failed to request external interrupt.\n");
                ret = -ENOENT;
                return ret;
        }

        if(request_irq(IRQ_EINT1, (void *)keyinterrupt_func,IRQF_DISABLED|IRQF_TRIGGER_FALLING, DRV_NAME, NULL)) 
        {
                printk("IRQ_EINT1 failed to request external interrupt.\n");
                ret = -ENOENT;
                return ret;
        }

        printk(KERN_INFO "%s successfully intq loaded\n", DRV_NAME);
        //*/
	//=section of inerterupt=======================================================================
	printk("This Module major number : 240\n");
	if (mydrv_major)
		result = register_chrdev_region(dev, 1, DEVICE_NAME);
	else {
		result = alloc_chrdev_region(&dev,0, 1, DEVICE_NAME);
		mydrv_major = MAJOR(dev);
	}
	if (result < 0) {
		printk(KERN_WARNING "mydrv: unable to get major %d\n", mydrv_major);
		return result;
	}
	if (mydrv_major == 0)
		mydrv_major = result;

	mydrv_setup_cdev(MydrvDevs,0, &mydrv_fops);
	printk("Hello.ko module init done\n");	

	return 0;
}

static void __exit cleanup(void)
{
	cdev_del(MydrvDevs);
	unregister_chrdev_region(MKDEV(mydrv_major, 0), 1);
	printk("hello.ko DD module exit done\n");
	//=====================================================
	///*
	printk(KERN_INFO "Goodbye, world 4.\n");

        free_irq(IRQ_EINT0, NULL);
        free_irq(IRQ_EINT1, NULL);

    printk(KERN_INFO "%s successfully removed\n", DRV_NAME);
	//*/
}

module_init(init);
module_exit(cleanup);
/* Get rid of taint message by declaring code as GPL. */
MODULE_LICENSE("GPL");
MODULE_AUTHOR(DRIVER_AUTHOR);		/* Who wrote this module? */
MODULE_DESCRIPTION(DRIVER_DESC);	/* What does this module do */
MODULE_SUPPORTED_DEVICE("testdevice");
