#define rGPLCON1 *(volatile unsigned long *)(kva + 4)
#define rGPLDAT *(volatile unsigned long *)(kva + 8)
#define rGPMCON *(volatile unsigned long *)(kva + 0x10)
#define rGPMDAT *(volatile unsigned long *)(kva + 0x14)

static void *kva;

kva = ioremap(0x7F008810,28) ;
	printk("kva = 0x%x\n",(int)kva);




#include "../lib2450/Uart.h"
#include "../lib2450/Timer.h" // Delay()
#include <stdlib.h> // rand()


// 0x56000060번�?�?4바이??R/W ?????�는 매크�??�의
#define GPGCON  (*(volatile unsigned long *)0x56000060)

// 0x56000064번�?�?4바이??R/W ?????�는 매크�??�의
#define GPGDAT  (*(volatile unsigned long *)0x56000064)


void Init_Led(void)
{
	// 1. GPGDAT 4,5,6,7??HIGH(1) 출력 (LED OFF)
	GPGDAT |= 0xf << 4;
	
	// 2. GPGCON 4,5,6,7??출력(Output) 모드�??�정
	GPGCON &= ~(0xff << 8);
	GPGCON |= 0x55 << 8;
}

void Led_On(int num)
{
	/* 3. num??1?�면 GPGDAT4??LOW 출력(LED ON)
     *    num??2?�면 GPGDAT5??LOW 출력
     *    num??3?�면 GPGDAT6??LOW 출력
     *    num??4?�면 GPGDAT7??LOW 출력            */
	 GPGDAT &= ~(0x1  <<  3+num);
}

void Led_Off(int num)
{
	/* 4. num??1?�면 GPGDAT4??HIGH 출력(LED OFF)
     *    num??2?�면 GPGDAT5??HIGH 출력
     *    num??3?�면 GPGDAT6??HIGH 출력
     *    num??4?�면 GPGDAT7??HIGH 출력            */
	 GPGDAT |= (0x1  <<  3+num);
}

void User_Main()
{
	int ranNum = 0;
	
    Init_Led();
	
	while(1)
	{
		ranNum = 1 + rand() % 4;
		
		Led_On(ranNum);
		
		Timer_Delay(500);
		
		Led_Off(ranNum);
	}
}